# AYZE Key Panel (Discloud)

Painel de keys (FastAPI + Jinja2) com API usada pelo `ayzemenu.lua`.

## Publicar na Discloud
1. Edite o `.env` (`ADMIN_PASSWORD`, `SESSION_SECRET`) e, no `discloud.config`, troque `ID` por um subdomínio livre (`ID=seunome.discloud.app`). Use o mesmo endereço em `PUBLIC_BASE_URL`.
2. Compacte tudo (sem pasta por fora) em um .zip e faça o upload na Discloud.
3. Abra `https://SEU-SUBDOMINIO.discloud.app/health` e depois `/login`.
4. No `ayzemenu.lua`, troque `API_BASE` por `https://SEU-SUBDOMINIO.discloud.app`.

O banco é SQLite (`ayze.db`) e fica salvo no disco da Discloud.
